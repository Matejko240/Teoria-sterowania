%WYSZUKAJ_BD - funkcja, która wyświetla na ekranie (ze stronnicowaniem)
%nazwy systemów dynamicznych, zawierające w sobie ciąg znaków string.

function wyszukaj_bd(string)
    global baza;
    fID=fopen(string)
end